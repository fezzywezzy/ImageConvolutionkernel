package ie.gmit.dip;

public class Runner {
	
	public static void main(String[] args) throws Exception{
		
		Menu m = new Menu();
		m.start();
	}
}
